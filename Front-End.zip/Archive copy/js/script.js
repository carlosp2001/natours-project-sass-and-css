"use strict";

function handleClick() {
	if (document.getElementById('small').checked) {
		location.href = "turismos.html";
	} else if (document.getElementById('large').checked) {
		location.href = "camionetas.html";
	}

}

